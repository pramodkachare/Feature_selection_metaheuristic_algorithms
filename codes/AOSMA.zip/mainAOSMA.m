% Adaptive Opposition Slime Mould Algorithm (AOSMA) source Code Version 1.0
%
% Developed in MATLAB R2018b
%
% Author and programmer: 
% Dr Manoj Kumar Naik
% Faculty of Engineering and Technology, Siksha O Anusandhan, Bhubaneswar, Odisha � 751030, India 
% e-mail:       naik.manoj.kumar@gmail.com
% ORCID:        https://orcid.org/0000-0002-8077-1811
% SCOPUS:       https://www.scopus.com/authid/detail.uri?authorId=35753522900
% Publons:      https://publons.com/researcher/2057920/manoj-kumar-naik/
% G-Scholar:    https://scholar.google.co.in/citations?user=tX-8Xw0AAAAJ&hl=en 
% Researchgate: https://www.researchgate.net/profile/Manoj_Naik9
% DBLP:         https://dblp.uni-trier.de/pers/k/Kumar:Naik_Manoj
%_____________________________________________________________________________________________________           
% Please cite to the main paper:
% ******************************
% M. K. Naik, R. Panda, and A. Abraham, �Adaptive opposition slime mould algorithm,� 
% Soft Comput., Aug. 2021, 
% doi: 10.1007/s00500-021-06140-2.
%
% You can get the preprint of this paper from:
% ********************************************
% https://www.researchsquare.com/article/rs-724180/v1
% doi: 10.21203/rs.3.rs-724180/v1
%
% This program using the framework of SMA by Ali Asghar Heidari
% https://aliasgharheidari.com/SMA.html
%_____________________________________________________________________________________________________


clearvars
close all
clc

disp('The AOSMA is tracking the problem');

N=30; % Number of slime mould
Function_name='F5' % Name of the test function that can be from F1 to F23 
MaxIT=500; % Maximum number of iterations

[lb,ub,dim,fobj]=Get_Functions_details(Function_name); % Function details

Times=21; %Number of independent times you want to run the AOSMA
display(['Number of independent runs: ', num2str(Times)]);

for i=1:Times
[Destination_fitness(i),bestPositions(i,:),Convergence_curve(i,:)]=AOSMA(N,MaxIT,lb,ub,dim,fobj);
display(['The optimal fitness of AOSMA is: ', num2str(Destination_fitness(i))]);
end

[bestfitness,index]=min(Destination_fitness);
disp('--------Best Fitness, Average Fitness, Standard Deviation and Best Solution--------');
display(['The best fitness of AOSMA is: ', num2str(bestfitness)]);
display(['The average fitness of AOSMA is: ', num2str(mean(Destination_fitness))]);
display(['The standard deviation fitness of AOSMA is: ', num2str(std(Destination_fitness))]);
display(['The best location of AOSMA is: ', num2str(bestPositions(index,:))]);

semilogy(Convergence_curve(index,:),'LineWidth',3);
xlabel('Iterations');
ylabel('Best fitness obtained so far');
legend('AOSMA');
box on;
axis tight;
grid off;









