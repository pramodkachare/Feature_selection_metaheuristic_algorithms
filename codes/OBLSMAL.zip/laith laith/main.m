

clear all 
close all
clc

N=10; % Number of search agents

Function_name='F1'; % Name of the test function, range from F1-F13

T=500; % Maximum number of iterations

dimSize = 100;   %dimension size

% Load details of the selected benchmark function
[lb,ub,dim,fobj]=Get_Functions_SMA(Function_name,dimSize);

[Destination_fitness,bestPositions,Convergence_curve1]=SMA(N,T,lb,ub,dim,fobj);
[Destination_fitness,bestPositions,Convergence_curve2]=OBLSMA(N,T,lb,ub,dim,fobj);
[Destination_fitness,bestPositions,Convergence_curve3]=OBLSMAL(N,T,lb,ub,dim,fobj);

% %Draw objective space
figure,

semilogy(Convergence_curve1,'Color','b','LineWidth',1);
hold on
semilogy(Convergence_curve2,'Color','g','LineWidth',1);
semilogy(Convergence_curve3,'Color','r','LineWidth',1);
title('Convergence curve')
xlabel('Iteration');
ylabel('Best fitness obtained so far');
axis tight
grid off
box on
legend('SMA','OBLSMA','OBLSMAL')
% 
% display(['The best location of SMA is: ', num2str(bestPositions)]);
% display(['The best fitness of SMA is: ', num2str(Destination_fitness)]);

        



